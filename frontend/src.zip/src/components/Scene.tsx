import React, { useRef, useMemo } from 'react';
import { Canvas } from '@react-three/fiber';
import { OrbitControls, Grid, GizmoHelper, GizmoViewport, TransformControls } from '@react-three/drei';
import type { OrbitControls as OrbitControlsType } from 'three-stdlib';
import * as THREE from 'three';
import { NodeMesh } from './NodeMesh';
import { Edges } from './Edges';
import { NodeItem, ResolvedEdge, getRouteEdgeKeys } from '../lib/graphViewerUtils';

interface SceneProps {
  nodes: NodeItem[];
  resolvedEdges: ResolvedEdge[];
  selectedNode: NodeItem | null;
  onSelectNode: (node: NodeItem | null) => void;
  showGrid: boolean;
  showAxes: boolean;
  showLabels: boolean;
  debugMode: boolean;
  onUpdateNodePosition?: (id: string, x: number, y: number, z: number) => void;
  snapToGrid?: boolean;
  // Route Navigation Props
  routePath?: string[];
  sourceId?: string | null;
  destinationId?: string | null;
  illuminatedNodeIds?: Set<string>;
  illuminatedEdgeKeys?: Set<string>;
  activeNodeId?: string | null;
  activeEdgeKey?: string | null;
}

export interface CameraControlHandle {
  resetCamera: () => void;
  setTopView: () => void;
  setSideView: () => void;
  setIsometricView: () => void;
}

interface NodeTransformGizmoProps {
  node: NodeItem;
  onUpdateNodePosition?: (id: string, x: number, y: number, z: number) => void;
  snapToGrid?: boolean;
}

const NodeTransformGizmo: React.FC<NodeTransformGizmoProps> = ({
  node,
  onUpdateNodePosition,
  snapToGrid,
}) => {
  const [target, setTarget] = React.useState<THREE.Group | null>(null);

  // Synchronize target position when node coordinates update
  React.useLayoutEffect(() => {
    if (target) {
      target.position.set(node.x, node.y, node.z);
    }
  }, [target, node.id, node.x, node.y, node.z]);

  return (
    <>
      <group ref={setTarget} position={[node.x, node.y, node.z]} />
      {target && (
        <TransformControls
          object={target}
          mode="translate"
          size={0.75}
          translationSnap={snapToGrid ? 1 : undefined}
          onObjectChange={() => {
            const pos = target.position;
            onUpdateNodePosition?.(
              node.id,
              Math.round(pos.x * 10) / 10,
              Math.round(pos.y * 10) / 10,
              Math.round(pos.z * 10) / 10
            );
          }}
        />
      )}
    </>
  );
};

export const Scene: React.FC<SceneProps> = ({
  nodes,
  resolvedEdges,
  selectedNode,
  onSelectNode,
  showGrid,
  showAxes,
  showLabels,
  debugMode,
  onUpdateNodePosition,
  snapToGrid = false,
  routePath = [],
  sourceId = null,
  destinationId = null,
  illuminatedNodeIds,
  illuminatedEdgeKeys,
  activeNodeId = null,
  activeEdgeKey = null,
}) => {
  const controlsRef = useRef<OrbitControlsType>(null);

  // Compute neighboring node IDs for selected node (direct edge partners)
  const neighborIds = useMemo(() => {
    if (!selectedNode) return new Set<string>();
    const neighbors = new Set<string>();
    for (const re of resolvedEdges) {
      if (re.isValid && re.source && re.target) {
        if (re.source.id === selectedNode.id) {
          neighbors.add(re.target.id);
        } else if (re.target.id === selectedNode.id) {
          neighbors.add(re.source.id);
        }
      }
    }
    return neighbors;
  }, [selectedNode, resolvedEdges]);

  // Derived sets for route highlighting
  const isRouteActive = routePath.length > 0;
  const routeWaypointSet = useMemo(() => new Set(routePath), [routePath]);
  const activeRouteEdgeKeys = useMemo(
    () => new Set(getRouteEdgeKeys(routePath)),
    [routePath]
  );

  return (
    <div className="relative w-full h-full bg-slate-950 overflow-hidden">
      <Canvas
        camera={{ position: [35, 45, 55], fov: 45, near: 0.1, far: 1000 }}
        shadows
        onPointerDown={(e) => {
          // Deselect when clicking on empty canvas background
          if (e.target === e.currentTarget) {
            onSelectNode(null);
          }
        }}
      >
        <color attach="background" args={['#090D16']} />
        <fog attach="fog" args={['#090D16', 60, 160]} />

        {/* Ambient & Directional Lights */}
        <ambientLight intensity={0.7} />
        <directionalLight
          position={[30, 45, 20]}
          intensity={1.2}
          castShadow
          shadow-mapSize-width={2048}
          shadow-mapSize-height={2048}
        />
        <directionalLight position={[-20, 25, -20]} intensity={0.4} color="#38BDF8" />

        {/* Orbit Controls */}
        <OrbitControls
          ref={controlsRef}
          makeDefault
          enableDamping
          dampingFactor={0.06}
          minDistance={5}
          maxDistance={150}
          maxPolarAngle={Math.PI / 2 + 0.05} // Prevent dipping too far below horizon
        />

        {/* Infinite Reference Grid */}
        {showGrid && (
          <Grid
            position={[0, -0.01, 0]}
            args={[120, 120]}
            cellSize={2}
            cellThickness={0.7}
            cellColor="#1E293B"
            sectionSize={10}
            sectionThickness={1.2}
            sectionColor="#334155"
            fadeDistance={100}
            fadeStrength={1.2}
            infiniteGrid
          />
        )}

        {/* 3D Axis Helper at Origin */}
        {showAxes && (
          <group position={[0, 0.01, 0]}>
            <primitive object={new THREE.AxesHelper(10)} />
          </group>
        )}

        {/* Orientation Compass Gizmo */}
        <GizmoHelper alignment="bottom-right" margin={[70, 70]}>
          <GizmoViewport
            axisColors={['#EF4444', '#10B981', '#3B82F6']}
            labelColor="#F8FAFC"
          />
        </GizmoHelper>

        {/* Render Edges (Pathways) */}
        <Edges
          resolvedEdges={resolvedEdges}
          selectedNode={selectedNode}
          activeRouteEdgeKeys={activeRouteEdgeKeys}
          illuminatedEdgeKeys={illuminatedEdgeKeys}
          currentActiveEdgeKey={activeEdgeKey}
        />

        {/* Render Nodes (Spheres + Labels) */}
        <group>
          {nodes.map((node) => (
            <NodeMesh
              key={node.id}
              node={node}
              isSelected={selectedNode?.id === node.id}
              isNeighbor={neighborIds.has(node.id)}
              onSelect={onSelectNode}
              showLabels={showLabels}
              debugMode={debugMode}
              isSource={node.id === sourceId}
              isDestination={node.id === destinationId}
              isRouteWaypoint={routeWaypointSet.has(node.id)}
              isIlluminated={illuminatedNodeIds?.has(node.id)}
              isCurrentStep={node.id === activeNodeId}
              isRouteActive={isRouteActive}
            />
          ))}
        </group>

        {/* 3D Transform Gizmo for in-scene node dragging in Debug Mode */}
        {debugMode && selectedNode && (
          <NodeTransformGizmo
            key={selectedNode.id}
            node={selectedNode}
            onUpdateNodePosition={onUpdateNodePosition}
            snapToGrid={snapToGrid}
          />
        )}
      </Canvas>
    </div>
  );
};
